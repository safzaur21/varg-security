<?php
declare(strict_types=1);
require __DIR__ . '/../src/bootstrap.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') verify_csrf();

if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $password = (string)($_POST['password'] ?? '');
    $q = db()->prepare('SELECT id,email,full_name,password_hash,role,preferred_language,is_active FROM users WHERE email=? LIMIT 1');
    $q->execute([$email ?: '']);
    $u = $q->fetch();
    if ($u && (int)$u['is_active'] === 1 && password_verify($password, $u['password_hash'])) {
        session_regenerate_id(true);
        unset($u['password_hash']);
        $_SESSION['user'] = $u;
        audit((int)$u['id'], 'login', 'user', (int)$u['id']);
        header('Location: index.php'); exit;
    }
    $error = 'Login fehlgeschlagen';
}

if ($action === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = current_user();
    if ($u) audit((int)$u['id'], 'logout', 'user', (int)$u['id']);
    $_SESSION = [];
    session_destroy();
    header('Location: index.php'); exit;
}

if ($action === 'submit_shift' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = require_login();
    $date = (string)($_POST['work_date'] ?? '');
    $site = trim((string)($_POST['site_name'] ?? ''));
    $start = (string)($_POST['start_at'] ?? '');
    $end = (string)($_POST['end_at'] ?? '');
    $break = filter_var($_POST['break_minutes'] ?? 0, FILTER_VALIDATE_INT);
    if (!$date || !$site || !$start || !$end || $break === false || $break < 0 || $break > 600) {
        http_response_code(422); exit('Ungültige Eingaben');
    }
    $startDt = DateTime::createFromFormat('Y-m-d H:i', $date.' '.$start);
    $endDt = DateTime::createFromFormat('Y-m-d H:i', $date.' '.$end);
    if (!$startDt || !$endDt) { http_response_code(422); exit('Ungültiges Datum'); }
    if ($endDt <= $startDt) $endDt->modify('+1 day');
    $minutes = (int)(($endDt->getTimestamp()-$startDt->getTimestamp())/60);
    if ($minutes <= $break || $minutes > 24*60) { http_response_code(422); exit('Arbeitszeit prüfen'); }
    $q = db()->prepare('INSERT INTO shifts(user_id,work_date,site_name,start_at,end_at,break_minutes,notes) VALUES(?,?,?,?,?,?,?)');
    $q->execute([(int)$u['id'],$date,$site,$startDt->format('Y-m-d H:i:s'),$endDt->format('Y-m-d H:i:s'),$break,trim((string)($_POST['notes'] ?? ''))]);
    $id = (int)db()->lastInsertId();
    audit((int)$u['id'], 'shift_submitted', 'shift', $id, ['work_date'=>$date]);
    header('Location: index.php?sent=1'); exit;
}

if ($action === 'review_shift' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin = require_admin();
    $id = filter_var($_POST['shift_id'] ?? '', FILTER_VALIDATE_INT);
    $decision = $_POST['decision'] ?? '';
    if (!$id || !in_array($decision, ['approved','rejected'], true)) { http_response_code(422); exit('Ungültige Aktion'); }
    $q = db()->prepare("UPDATE shifts SET status=?, reviewed_by=?, reviewed_at=NOW(), review_note=? WHERE id=? AND status='pending'");
    $q->execute([$decision,(int)$admin['id'],trim((string)($_POST['review_note'] ?? '')),$id]);
    if ($q->rowCount()) audit((int)$admin['id'], 'shift_'.$decision, 'shift', $id);
    header('Location: index.php'); exit;
}

$user = current_user();
?><!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Varg Security Mitarbeiterportal</title>
<style>
body{margin:0;background:#0d141c;color:#f4f6f8;font:15px system-ui}header{padding:18px 5%;background:#101923;border-bottom:1px solid #2b3948;display:flex;justify-content:space-between;align-items:center}.brand{font-weight:800;letter-spacing:.1em}.logo{display:inline-grid;place-items:center;border:1px dashed #8290a0;border-radius:8px;width:42px;height:42px;font-size:9px;vertical-align:middle;margin-right:10px}.wrap{max-width:1100px;margin:32px auto;padding:0 20px}.card{background:#17222e;border:1px solid #2b3948;border-radius:14px;padding:22px;margin:18px 0}input,button,textarea{font:inherit;padding:11px;border-radius:8px;border:1px solid #354454;background:#101923;color:white}input,textarea{width:100%;box-sizing:border-box;margin:5px 0 13px}button{cursor:pointer;background:#d52b39;border:0;font-weight:700}.secondary{background:#354454}label{color:#aab6c3;font-size:13px}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid #354454}th{color:#aab6c3}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.muted{color:#9eacba}.error{color:#ff8a94}@media(max-width:650px){.grid{grid-template-columns:1fr}table{font-size:12px}}
</style><header><div class="brand"><span class="logo">LOGO</span> VARG SECURITY <small class="muted">MITARBEITERPORTAL</small></div><?php if($user): ?><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="logout"><button class="secondary">Abmelden</button></form><?php endif ?></header><main class="wrap">
<?php if(!$user): ?><section class="card" style="max-width:420px;margin:50px auto"><h1>Anmeldung</h1><?php if(!empty($error)): ?><p class="error">Anmeldung fehlgeschlagen.</p><?php endif ?><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="login"><label>E-Mail</label><input name="email" type="email" required autocomplete="username"><label>Passwort</label><input name="password" type="password" required autocomplete="current-password"><button>Anmelden</button></form></section>
<?php else: ?><h1>Hallo, <?=h($user['full_name'])?></h1><p class="muted">Rolle: <?=h($user['role'])?></p>
<section class="card"><h2>Arbeitszeit eintragen</h2><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="submit_shift"><div class="grid"><div><label>Datum</label><input type="date" name="work_date" required></div><div><label>Einsatzort / Veranstaltung</label><input name="site_name" required></div><div><label>Beginn</label><input type="time" name="start_at" required></div><div><label>Ende</label><input type="time" name="end_at" required></div><div><label>Pause (Minuten)</label><input type="number" name="break_minutes" min="0" max="600" value="0"></div><div><label>Bemerkungen</label><input name="notes"></div></div><button>Zur Prüfung einreichen</button></form></section>
<section class="card"><h2>Meine Arbeitszeiten</h2><?php $q=db()->prepare('SELECT * FROM shifts WHERE user_id=? ORDER BY work_date DESC,id DESC');$q->execute([(int)$user['id']]);$rows=$q->fetchAll(); ?><table><tr><th>Datum</th><th>Objekt</th><th>Beginn–Ende</th><th>Status</th></tr><?php foreach($rows as $r): ?><tr><td><?=h($r['work_date'])?></td><td><?=h($r['site_name'])?></td><td><?=h(substr($r['start_at'],11,5).'–'.substr($r['end_at'],11,5))?></td><td><?=h($r['status'])?></td></tr><?php endforeach ?></table></section>
<?php if(in_array($user['role'],['super_admin','admin'],true)): ?><section class="card"><h2>Alle Einträge — Prüfung</h2><?php $rows=db()->query('SELECT s.*,u.full_name FROM shifts s JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC')->fetchAll(); ?><table><tr><th>Mitarbeiter</th><th>Datum</th><th>Objekt</th><th>Zeiten</th><th>Status</th><th>Aktion</th></tr><?php foreach($rows as $r): ?><tr><td><?=h($r['full_name'])?></td><td><?=h($r['work_date'])?></td><td><?=h($r['site_name'])?></td><td><?=h(substr($r['start_at'],11,5).'–'.substr($r['end_at'],11,5))?></td><td><?=h($r['status'])?></td><td><?php if($r['status']==='pending'): ?><form method="post" style="display:flex;gap:5px;flex-wrap:wrap"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="review_shift"><input type="hidden" name="shift_id" value="<?= (int)$r['id']?>"><button name="decision" value="approved">Genehmigen</button><button class="secondary" name="decision" value="rejected">Ablehnen</button></form><?php endif ?></td></tr><?php endforeach ?></table></section><?php endif ?>
<?php endif ?></main></html>
