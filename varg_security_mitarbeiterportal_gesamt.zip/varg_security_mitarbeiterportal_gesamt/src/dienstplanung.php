<?php
declare(strict_types=1);
// bootstrap.php is loaded by the main public entry point.

/*
 * Dienstplanung handlers.
 * Include from the main controller after bootstrap.php.
 * Every POST handler must call verify_csrf() before invoking these functions.
 */

function create_planned_shift(array $actor, array $input): int {
    if (!in_array($actor['role'] ?? '', ['super_admin','admin'], true)) {
        throw new RuntimeException('Forbidden');
    }
    $title = trim((string)($input['title'] ?? ''));
    $site = trim((string)($input['site_name'] ?? ''));
    $startRaw = (string)($input['starts_at'] ?? '');
    $endRaw = (string)($input['ends_at'] ?? '');
    $break = filter_var($input['break_minutes'] ?? 0, FILTER_VALIDATE_INT);
    $ids = $input['employee_ids'] ?? [];

    if ($title === '' || $site === '' || !is_array($ids) || count($ids) < 1 ||
        $break === false || $break < 0 || $break > 600) {
        throw new InvalidArgumentException('Invalid shift input');
    }
    $start = DateTime::createFromFormat('Y-m-d\TH:i', $startRaw);
    $end = DateTime::createFromFormat('Y-m-d\TH:i', $endRaw);
    if (!$start || !$end || $end <= $start) {
        throw new InvalidArgumentException('Invalid shift dates');
    }
    $duration = ($end->getTimestamp() - $start->getTimestamp()) / 60;
    if ($duration <= $break || $duration > 24 * 60) {
        throw new InvalidArgumentException('Invalid duration');
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        // Only active employee accounts may be assigned.
        $ids = array_values(array_unique(array_filter(array_map(
            static fn($v) => filter_var($v, FILTER_VALIDATE_INT),
            $ids
        ), static fn($v) => $v !== false && $v > 0)));
        if (!$ids) throw new InvalidArgumentException('Select at least one employee');

        $in = implode(',', array_fill(0, count($ids), '?'));
        $check = $pdo->prepare("SELECT id FROM users WHERE is_active=1 AND role='employee' AND id IN ($in)");
        $check->execute($ids);
        $validIds = array_map('intval', array_column($check->fetchAll(), 'id'));
        if (count($validIds) !== count($ids)) {
            throw new InvalidArgumentException('One or more selected accounts are invalid');
        }

        $q = $pdo->prepare("INSERT INTO shifts_plan(title,site_name,starts_at,ends_at,break_minutes,instructions,created_by)
                            VALUES(?,?,?,?,?,?,?)");
        $q->execute([
            $title, $site, $start->format('Y-m-d H:i:s'), $end->format('Y-m-d H:i:s'),
            $break, trim((string)($input['instructions'] ?? '')), (int)$actor['id']
        ]);
        $shiftId = (int)$pdo->lastInsertId();

        $assign = $pdo->prepare('INSERT INTO shift_plan_assignments(planned_shift_id,user_id) VALUES(?,?)');
        foreach ($validIds as $employeeId) $assign->execute([$shiftId, $employeeId]);

        audit((int)$actor['id'], 'planned_shift_created', 'planned_shift', $shiftId, [
            'employee_count' => count($validIds),
            'site_name' => $site,
            'starts_at' => $start->format(DateTime::ATOM),
        ]);
        $pdo->commit();
        return $shiftId;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function list_my_planned_shifts(array $user): array {
    $q = db()->prepare("SELECT p.id,p.title,p.site_name,p.starts_at,p.ends_at,p.break_minutes,p.instructions,p.status
        FROM shifts_plan p
        JOIN shift_plan_assignments a ON a.planned_shift_id=p.id
        WHERE a.user_id=? AND p.status='published' AND p.ends_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY p.starts_at ASC");
    $q->execute([(int)$user['id']]);
    return $q->fetchAll();
}

function list_all_planned_shifts(array $actor): array {
    if (!in_array($actor['role'] ?? '', ['super_admin','admin'], true)) {
        throw new RuntimeException('Forbidden');
    }
    return db()->query("SELECT p.*, u.full_name AS creator_name,
        GROUP_CONCAT(DISTINCT e.full_name ORDER BY e.full_name SEPARATOR ', ') AS employee_names,
        COUNT(DISTINCT a.user_id) AS employee_count
        FROM shifts_plan p
        JOIN users u ON u.id=p.created_by
        LEFT JOIN shift_plan_assignments a ON a.planned_shift_id=p.id
        LEFT JOIN users e ON e.id=a.user_id
        GROUP BY p.id
        ORDER BY p.starts_at DESC")->fetchAll();
}

function cancel_planned_shift(array $actor, int $shiftId): void {
    if (!in_array($actor['role'] ?? '', ['super_admin','admin'], true)) {
        throw new RuntimeException('Forbidden');
    }
    $q = db()->prepare("UPDATE shifts_plan SET status='cancelled' WHERE id=? AND status='published'");
    $q->execute([$shiftId]);
    if ($q->rowCount()) audit((int)$actor['id'], 'planned_shift_cancelled', 'planned_shift', $shiftId);
}
