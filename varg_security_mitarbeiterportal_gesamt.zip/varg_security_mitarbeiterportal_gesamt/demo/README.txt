VARG SECURITY MITARBEITERPORTAL — DEMO

Start:
1. Entpacken Sie das ZIP.
2. Öffnen Sie index.html in einem aktuellen Browser.

Enthalten:
- Deutsch/Russisch-Umschaltung
- Arbeitszeitformular mit Berechnung (auch über Mitternacht)
- lokale Demo-Historie und Monatsübersicht
- Platzhalter für das Firmenlogo

WICHTIG:
Dies ist nur ein Frontend-Prototyp. Es gibt KEINE echte Anmeldung, keine Server-Datenbank,
keine rollenbasierte Zugriffskontrolle, keine zentrale Datenspeicherung und keine Admin-Freigabe.
localStorage ist nicht für echte Mitarbeiter- oder Arbeitszeitdaten geeignet.
Vor produktivem Einsatz müssen Backend, sichere Authentifizierung, Rollen/Rechte,
Datenbank, Backups, HTTPS, Audit-Log und Datenschutz-/Arbeitszeit-Compliance umgesetzt werden.
Die Domain mitarbeiter.varg-security.de muss separat bei IONOS eingerichtet und auf das Hosting
geschaltet werden. Den Logo-Platzhalter in index.html können Sie durch Ihr Logo ersetzen.
